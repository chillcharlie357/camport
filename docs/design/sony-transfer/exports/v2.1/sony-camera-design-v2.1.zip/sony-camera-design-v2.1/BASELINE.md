# 已批准的视觉基线

用户于 2026-11-10 确认 v2 UI 设计。批准快照：`../baselines/sony-transfer-v2-approved/`。

快照包含 HTML、样式、字体、照片、PDF 和完整离线包；`BASELINE.json` 记录 SHA-256，可独立核对。后续变更不得覆盖快照。当前工作版本 v2.1 增加同名 RAW 与 JPG/PNG 合并显示和统一评分，继续使用已批准的颜色、字体与布局。
